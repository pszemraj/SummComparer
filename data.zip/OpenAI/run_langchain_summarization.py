"""
run_langchain_summarization.py - Generate summaries using langchain + LLMs

For usage details, run `python run_langchain_summarization.py --help` and fire will print the usage details.

Notes:
- you need to have OPENAI_API_KEY set as an environment variable (easiest way is export OPENAI_API_KEY=memes123)
- install the dependencies using:
pip install -U pip fire clean-text tqdm langchain openai
"""
import json
from datetime import datetime
from pathlib import Path

import fire
from cleantext import clean
from langchain.chains.summarize import load_summarize_chain
from langchain.chat_models import ChatOpenAI
from langchain.text_splitter import RecursiveCharacterTextSplitter
from tqdm.auto import tqdm
from functools import wraps


def record_args(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        args_dict = {}
        args_dict.update(zip(func.__code__.co_varnames, args))
        args_dict.update(kwargs)
        output_dir = args_dict.get("output_dir")
        path = Path(args_dict.get("input_dir"))
        if output_dir is None:
            # compute output_dir here
            output_dir = (
                path.parent
                / f"{path.stem}-{args_dict['model_name']}-generated-summaries"
            )
        with open(output_dir / "args.json", "w") as f:
            json.dump(args_dict, f, indent=4)
        return func(*args, **kwargs)

    return wrapper


def get_timestamp():
    return datetime.now().strftime("%Y%b%d%H-%M")


def read_and_clean_file(file_path, lower=False):
    with open(file_path, "r", encoding="utf-8") as f:
        context = clean(f.read(), lower=lower)
    return context


def save_output_to_file(out_dir, sub_dir, output, json_output, file_name):
    out_dir = Path(out_dir)
    out_dir = out_dir / sub_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    output_file = out_dir / f"{file_name}_summary.txt"

    with output_file.open("w", encoding="utf-8") as f:
        f.write(output)

    output_file = out_dir / f"{file_name}_summary.json"
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(json_output, f, ensure_ascii=False, indent=4)


@record_args
def generate_summaries(
    input_dir: str,
    output_dir: str = None,
    model_name: str = "gpt-3.5-turbo",
    chunk_size: str = 4096,
    chunk_overlap: int = 16,
    temperature: float = 0,
):
    """
    generate_summaries - Generate summaries using langchain + LLMs

    :param str input_dir: input directory containing text files
    :param str output_dir: output directory to save summaries, defaults to None (creates a new directory)
    :param str model_name: openai model name, defaults to "gpt-3.5-turbo"
    :param str chunk_size: size of chunks to split text into in tokens, defaults to 4096
    :param int chunk_overlap: number of tokens to overlap between chunks, defaults to 16
    :param float temperature: temperature to use for LLM, defaults to 0
    """
    llm = ChatOpenAI(model_name=model_name, temperature=temperature)
    text_splitter = RecursiveCharacterTextSplitter.from_tiktoken_encoder(
        model_name=model_name, chunk_size=chunk_size, chunk_overlap=chunk_overlap
    )
    chain_refine = load_summarize_chain(
        llm, chain_type="refine", return_intermediate_steps=True
    )
    chain_map_reduce = load_summarize_chain(
        llm, chain_type="map_reduce", return_intermediate_steps=True
    )

    path = Path(input_dir)
    assert path.exists(), f"Path {path} does not exist."

    output_dir = (
        output_dir or path.parent / f"{path.stem}-{model_name}-generated-summaries"
    )

    source_files = [f for f in path.iterdir() if f.is_file() and f.suffix == ".txt"]
    for i, doc_path in enumerate(tqdm(source_files, desc="Generating text"), start=1):
        file_name = Path(doc_path).stem
        input_text = read_and_clean_file(doc_path)
        docs = text_splitter.create_documents([input_text])

        refine_output = chain_refine(
            {"input_documents": docs}, return_only_outputs=True
        )
        map_reduce_output = chain_map_reduce(
            {"input_documents": docs}, return_only_outputs=True
        )

        save_output_to_file(
            output_dir,
            "refine_output",
            refine_output["output_text"],
            refine_output,
            file_name,
        )
        save_output_to_file(
            output_dir,
            "map_reduce_output",
            map_reduce_output["output_text"],
            map_reduce_output,
            file_name,
        )

    print(f"Generated {i} summaries. Output saved to\n\t{output_dir}.")


if __name__ == "__main__":
    fire.Fire(generate_summaries)
